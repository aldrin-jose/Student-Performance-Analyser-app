# Generated code do not commit.
file(TO_CMAKE_PATH "G:\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "G:\\prediction app\\student_app" PROJECT_DIR)

set(FLUTTER_VERSION "1.0.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=G:\\flutter"
  "PROJECT_DIR=G:\\prediction app\\student_app"
  "FLUTTER_ROOT=G:\\flutter"
  "FLUTTER_EPHEMERAL_DIR=G:\\prediction app\\student_app\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=G:\\prediction app\\student_app"
  "FLUTTER_TARGET=G:\\prediction app\\student_app\\lib\\main.dart"
  "DART_DEFINES=RkxVVFRFUl9WRVJTSU9OPTMuNDQuOQ==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049NmIxODJkMmM3NQ==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049NWEyYTZhNDJjYw==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMi4y"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=G:\\prediction app\\student_app\\.dart_tool\\package_config.json"
)
