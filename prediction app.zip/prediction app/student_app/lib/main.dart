import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() => runApp(const ScorePredictorApp());

class ScorePredictorApp extends StatelessWidget {
  const ScorePredictorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Student Score Prediction App',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.indigo,
          brightness: Brightness.light,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: Colors.grey.shade300),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: Colors.grey.shade300),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: Colors.indigo, width: 2),
          ),
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _formKey = GlobalKey<FormState>();
  final _hoursController = TextEditingController();
  final _previousScoresController = TextEditingController();
  final _sleepHoursController = TextEditingController();
  final _samplePapersController = TextEditingController();

  double? _predictedScore;
  String? _errorMessage;
  bool _isLoading = false;

  Future<void> _fetchPrediction() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    final uri = Uri.parse('http://127.0.0.1:8000/predict');

    try {
      final response = await http.post(
        uri,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'hours_studied': double.parse(_hoursController.text),
          'previous_scores': double.parse(_previousScoresController.text),
          'sleep_hours': double.parse(_sleepHoursController.text),
          'sample_papers': double.parse(_samplePapersController.text),
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _predictedScore = (data['predicted_score'] as num).toDouble();
        });
      } else {
        setState(() => _errorMessage = 'Server error (${response.statusCode})');
      }
    } catch (e) {
      setState(() => _errorMessage = 'Failed to connect to API server.');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _resetForm() {
    _formKey.currentState?.reset();
    _hoursController.clear();
    _previousScoresController.clear();
    _sleepHoursController.clear();
    _samplePapersController.clear();
    setState(() {
      _predictedScore = null;
      _errorMessage = null;
    });
  }

  String? _validateInput(String? value, String fieldName, {double? max}) {
    if (value == null || value.trim().isEmpty) {
      return 'Please enter $fieldName';
    }
    final numValue = double.tryParse(value);
    if (numValue == null || numValue < 0) {
      return 'Enter a valid positive number';
    }
    if (max != null && numValue > max) {
      return 'Value cannot exceed $max';
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.indigo.shade900,
              Colors.indigo.shade700,
              Colors.blueAccent.shade700,
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24.0),
              child: Container(
                constraints: const BoxConstraints(maxWidth: 520),
                child: Column(
                  children: [
                    // Animated Title on Load
                    TweenAnimationBuilder<double>(
                      tween: Tween<double>(begin: 0.0, end: 1.0),
                      duration: const Duration(milliseconds: 900),
                      curve: Curves.easeOutBack,
                      builder: (context, value, child) {
                        return Transform.scale(
                          scale: value,
                          child: Opacity(
                            opacity: value.clamp(0.0, 1.0),
                            child: child,
                          ),
                        );
                      },
                      child: Column(
                        children: [
                          const Icon(
                            Icons.auto_graph_rounded,
                            size: 56,
                            color: Colors.white,
                          ),
                          const SizedBox(height: 8),
                          const Text(
                            'Student Score Prediction App',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 26,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                              letterSpacing: 0.5,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'AI-Powered Exam Performance Estimator',
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.8),
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 28),

                    // Main Input Form Card
                    Card(
                      elevation: 12,
                      shadowColor: Colors.black38,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(24),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(28.0),
                        child: Form(
                          key: _formKey,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              const Text(
                                'Performance Metrics',
                                style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 18),
                              TextFormField(
                                controller: _hoursController,
                                keyboardType: TextInputType.number,
                                decoration: const InputDecoration(
                                  labelText: 'Hours Studied',
                                  prefixIcon: Icon(Icons.timer_outlined),
                                ),
                                validator: (val) => _validateInput(
                                    val, 'hours studied',
                                    max: 24),
                              ),
                              const SizedBox(height: 16),
                              TextFormField(
                                controller: _previousScoresController,
                                keyboardType: TextInputType.number,
                                decoration: const InputDecoration(
                                  labelText: 'Previous Exam Score (%)',
                                  prefixIcon: Icon(Icons.school_outlined),
                                ),
                                validator: (val) => _validateInput(
                                    val, 'previous score',
                                    max: 100),
                              ),
                              const SizedBox(height: 16),
                              TextFormField(
                                controller: _sleepHoursController,
                                keyboardType: TextInputType.number,
                                decoration: const InputDecoration(
                                  labelText: 'Sleep Hours',
                                  prefixIcon: Icon(Icons.bedtime_outlined),
                                ),
                                validator: (val) => _validateInput(
                                    val, 'sleep hours',
                                    max: 24),
                              ),
                              const SizedBox(height: 16),
                              TextFormField(
                                controller: _samplePapersController,
                                keyboardType: TextInputType.number,
                                decoration: const InputDecoration(
                                  labelText: 'Sample Papers Practiced',
                                  prefixIcon: Icon(Icons.assignment_outlined),
                                ),
                                validator: (val) =>
                                    _validateInput(val, 'sample papers'),
                              ),
                              const SizedBox(height: 28),

                              // Submit Button
                              SizedBox(
                                height: 50,
                                child: ElevatedButton(
                                  onPressed:
                                      _isLoading ? null : _fetchPrediction,
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.indigo,
                                    foregroundColor: Colors.white,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    elevation: 2,
                                  ),
                                  child: _isLoading
                                      ? const SizedBox(
                                          height: 20,
                                          width: 20,
                                          child: CircularProgressIndicator(
                                            color: Colors.white,
                                            strokeWidth: 2,
                                          ),
                                        )
                                      : const Text(
                                          'Predict Final Score',
                                          style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                ),
                              ),

                              // Refresh / Reset Button
                              const SizedBox(height: 10),
                              OutlinedButton.icon(
                                onPressed: _resetForm,
                                icon: const Icon(Icons.refresh_rounded,
                                    size: 18),
                                label: const Text('Reset / Refresh Fields'),
                                style: OutlinedButton.styleFrom(
                                  foregroundColor: Colors.grey.shade700,
                                  side: BorderSide(color: Colors.grey.shade300),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                ),
                              ),

                              // Results and Pass/Fail Badge
                              if (_predictedScore != null ||
                                  _errorMessage != null) ...[
                                const SizedBox(height: 24),
                                const Divider(),
                                const SizedBox(height: 12),
                                if (_predictedScore != null) ...[
                                  Container(
                                    padding: const EdgeInsets.all(20),
                                    decoration: BoxDecoration(
                                      color: _predictedScore! >= 40.0
                                          ? Colors.green.shade50
                                          : Colors.red.shade50,
                                      borderRadius: BorderRadius.circular(16),
                                      border: Border.all(
                                        color: _predictedScore! >= 40.0
                                            ? Colors.green.shade200
                                            : Colors.red.shade200,
                                      ),
                                    ),
                                    child: Column(
                                      children: [
                                        const Text(
                                          'Estimated Score',
                                          style: TextStyle(
                                            fontSize: 14,
                                            color: Colors.black54,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          '${_predictedScore!.toStringAsFixed(1)}%',
                                          style: TextStyle(
                                            fontSize: 36,
                                            fontWeight: FontWeight.bold,
                                            color: _predictedScore! >= 40.0
                                                ? Colors.green.shade900
                                                : Colors.red.shade900,
                                          ),
                                        ),
                                        const SizedBox(height: 12),

                                        // Pass / Fail Status Badge
                                        Container(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 16, vertical: 8),
                                          decoration: BoxDecoration(
                                            color: _predictedScore! >= 40.0
                                                ? Colors.green
                                                : Colors.red,
                                            borderRadius:
                                                BorderRadius.circular(30),
                                          ),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Icon(
                                                _predictedScore! >= 40.0
                                                    ? Icons.check_circle_rounded
                                                    : Icons.cancel_rounded,
                                                color: Colors.white,
                                                size: 20,
                                              ),
                                              const SizedBox(width: 8),
                                              Text(
                                                _predictedScore! >= 40.0
                                                    ? 'STATUS: PASS'
                                                    : 'STATUS: FAIL',
                                                style: const TextStyle(
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.bold,
                                                  letterSpacing: 1.1,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                                if (_errorMessage != null)
                                  Text(
                                    _errorMessage!,
                                    textAlign: TextAlign.center,
                                    style: const TextStyle(
                                      color: Colors.red,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                              ],
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}